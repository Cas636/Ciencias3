/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

/**
 *
 * @author yunei
 */
public class Util {

    public static String[] splitSentence(String sentence) {
        String[] aux = sentence.replace("\n", " ").replace("\t", " ").split(" ");
        int blankCounter = 0;
        for (String s : aux) {
            if (s.isBlank()) {
                blankCounter++;
            }
        }
        String[] result = new String[aux.length - blankCounter];
        int i = 0;
        for (String s : aux) {
            if (!s.isBlank()) {
                result[i] = s;
                i++;
            }
        }
        return result;
    }

}
