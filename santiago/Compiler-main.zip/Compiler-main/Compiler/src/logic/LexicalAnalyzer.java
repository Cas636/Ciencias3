/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logic;

import util.WordList;

/**
 *
 * @author yunei
 */
public class LexicalAnalyzer {
    
    public boolean lexicalCheck(String sentence,WordList wordList){
        System.out.println(wordsContained(sentence,wordList));
        return  wordListCheck(sentence,wordList) && 
                identifiersCheck(sentence,wordList);
    }
    
    private boolean wordListCheck(String sentence, WordList wordList){
        String[] words = util.Util.splitSentence(sentence);
        for(String w:words){
            if(!wordList.Contains(w)){
                return false;
            }
        }
        return true;
    }
    
    private boolean identifiersCheck(String sentence, WordList wordList){
        
        return true;
    }
    
    public String wordsContained(String sentence, WordList wordList){
        String result = "";
        String[] words = util.Util.splitSentence(sentence);
        int cont = 0;
        for(String w:words){
            System.out.println(w);
            if(wordList.Contains(w)){
                result += wordList.getWord(w)+": "+wordList.getType(w)+"\n";
                cont++;
            }
        }
        if(cont != words.length){
            result = "SENTENCIA INVALIDA";
        }
        return result;
    }
    
}
