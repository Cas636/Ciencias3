/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logic;

import util.WordList;

/**
 *
 * @author yunei
 */
public class Compiler {
 
    private WordList wordList;
    
    public Compiler(String wordsToCheck){
        wordList = new WordList();
        LexicalAnalyzer la = new LexicalAnalyzer();
        System.out.println(la.lexicalCheck(wordsToCheck, wordList));
    }
    
    //check sentences
    //show errors
        //errors type
    
}
