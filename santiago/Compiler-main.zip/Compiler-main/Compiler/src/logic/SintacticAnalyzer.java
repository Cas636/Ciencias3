/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logic;

import util.WordList;
import java.util.ArrayList;
import java.util.StringTokenizer;

/**
 *
 * @author 57320
 */
public class SintacticAnalyzer {
    
    ArrayList<String> sentence = new ArrayList<>();
    boolean[] keywords; 
    String[] type;
    
    
    public void fill(String sentence, WordList wl){//Llena el array token por token
        StringTokenizer tokens = new StringTokenizer(sentence, " ");
        while(tokens.hasMoreTokens()){
            this.sentence.add(tokens.nextToken());
        }
        keywords = new boolean[this.sentence.size()];
        type = new String[this.sentence.size()];
        for(int i = 0; i < this.sentence.size(); i++){
            
            keywords[i] = wl.Contains(this.sentence.get(i));
            System.out.println(keywords[i]);
            
            if(keywords[i]){
                type[i] = wl.getType(this.sentence.get(i));
            }else{
                type[i] = "";
            }
            
        }
    }
    
    public boolean verify(){
        boolean posible = false;
        if(!keywords[0]){
            return false;
        }
        
        for(int i = 0; i < sentence.size(); i++){
            if(keywords[i] && i < sentence.size()-1){
                if(keywords[i+1]){
                    
                    posible = twoWords(i);
                }else{
                     posible = oneWord(i);
                }
            }else if(keywords[i]){
                posible = oneWord(i);
            }
        }
        return posible; 
    }
    
    public boolean oneWord(int i){
        
        if(type[i].equals("AGREGADOS")){
            return false;
        }else if(type[i].equals("OPERADORES")){
            return true;
        }else if(type[i].equals("PALABRAS RESERVADAS")){
            return true;
        }
        return false;
    }
    public boolean twoWords(int i){
        
        //Verifica que no sean de igual tipo. 
        if(type[i].equals(type[i+1]) && !"INSTRUMENTOS DE STRING".equals(type[i])){
            keywords[i] = false;
            keywords[i+1] = false;
            return false;
        }else if("INSTRUMENTOS DE STRING".equals(type[i])){
            keywords[i] = false;
            keywords[i+1] = false;
            return true; 
        }
        
        if(type[i].equals("OPERADORES") && type[i+1].equals("IDENTIFICADOR")){
            keywords[i] = false;
            keywords[i+1] = false;
            return true;
        }
        
        if(type[i].equals("OPERADORES") && type[i+1].equals("PALABRAS RESERVADAS")){
            keywords[i] = false;
            keywords[i+1] = false;
            return true;
        }
        
           if(type[i].equals("OPERADORES") && type[i+1].equals("CONSTANTES")){
            keywords[i] = false;
            keywords[i+1] = false;
            return true;
        }
        
        
        return false;
    }
    
    
    
    
    
}
