# analizador-lexico

## Integrantes

Johan Castaño - 20191020029

Jesús Leiva - 20191020132

# Build
``` sh
javac src/com/udistrital/lexer/Main.java -cp src/ -d bin/
```

# Execute

``` sh
java -cp bin/ com.udistrital.lexer.Main test-files/algorithmcontroller.cpp test-files/main.cpp test-files/util.cpp
```

Enlace del video: https://youtu.be/SUUWgh6mOpU

Enlace repositorio: https://github.com/Bermudez0622/analizador-lexico.git